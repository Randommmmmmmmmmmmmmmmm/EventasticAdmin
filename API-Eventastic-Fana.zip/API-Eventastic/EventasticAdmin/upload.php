<?php
require "../db.php";

$target_dir = "../dewan/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if(isset($_POST["signup"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
    echo "File is not an image.";
    $uploadOk = 0;
  }
}

// Check if file already exists
if (file_exists($target_file)) {
  echo "Sorry, file already exists.";
  $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
   $stmt = $conn->prepare("INSERT INTO requests (fullname, email, place_area, venue_name, venue_book_status, venue_ratings, venue_image, venue_latitude, venue_longitude, venue_search, message, datetimes) VALUES(:fullname, :email, :place_area, :venue_name, :venue_book_status, :venue_ratings, :venue_image, :venue_latitude, :venue_longitude, :venue_search, :message, CURRENT_TIMESTAMP)");
   
    // $stmt->bindParam(':uid', $uid, PDO::PARAM_STR);
    $stmt->bindParam(':fullname', $fullname, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':place_area', $place_area, PDO::PARAM_STR);
    $stmt->bindParam(':venue_name', $venue_name, PDO::PARAM_STR);
    $stmt->bindParam(':venue_book_status', $venue_book_status, PDO::PARAM_STR);
    $stmt->bindParam(':venue_ratings', $venue_ratings, PDO::PARAM_STR);
    $stmt->bindParam(':venue_image', basename($_FILES["fileToUpload"]["name"]), PDO::PARAM_STR);
    $stmt->bindParam(':venue_latitude', $venue_latitude, PDO::PARAM_STR);
    $stmt->bindParam(':venue_longitude', $venue_longitude, PDO::PARAM_STR);
    $stmt->bindParam(':venue_search', $venue_search, PDO::PARAM_STR);
    $stmt->bindParam(':message', $message, PDO::PARAM_STR);
    // $stmt->bindParam(':datetime', $datetime, PDO::PARAM_STR);
       
    // $uid = $_POST['uid'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $place_area = $_POST['place_area'];
    $venue_name = $_POST['venue_name'];
    $venue_book_status = $_POST['venue_book_status'];
    $venue_ratings = $_POST['venue_ratings'];
    $venue_latitude = $_POST['venue_latitude'];
    $venue_longitude = $_POST['venue_longitude'];
    $venue_search = $_POST['venue_search'];

    $message = "$fullname would like to request an account.";
       
    $stmt->execute();
    
    header('Location: login.php');
 
            // echo "cat";
            // $fullname = $_POST['fullname'];
            // $email = $_POST['email'];
            // $place_area = $_POST['place_area'];
            // $venue_name = $_POST['venue_name'];
            // $venue_book_status = $_POST['venue_book_status'];
            // $venue_ratings = $_POST['venue_ratings'];
            // // $venue_image = $_POST['venue_image'];
            // $venue_latitude = $_POST['venue_latitude'];
            // $venue_longitude = $_POST['venue_longitude'];

            // $message = "$fullname would like to request an account.";

            // $query = "INSERT INTO `requests` (`venue_id`, `fullname`, `email`, `place_area`, `venue_name`, `venue_book_status`, `venue_ratings`,`venue_latitude`,`venue_longitude`, `message`, `date`) VALUES (NULL, '$fullname', '$email', '$place_area', '$venue_name', '$venue_book_status', '$venue_ratings', '$venue_latitude','$venue_longitude', '$message', CURRENT_TIMESTAMP)";
            // if(performQuery($query)){
            //     echo "<script>alert('Your account request is now pending for approval. Please wait for confirmation. Thank you.')</script>";
            // }else{
            //     echo "<script>alert('Unknown error occured.')</script>";
            // }
        
        echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}
?>