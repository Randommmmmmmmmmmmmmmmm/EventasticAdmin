
<?php
 
include_once 'database.php';
 
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
 
// //Create
// if (isset($_POST['create'])) {

//   try {
 
//     $stmt = $conn->prepare("INSERT INTO venue_list(fullname, email, place_area, venue_name, venue_book_status, venue_ratings, venue_latitude, venue_longitude, venue_search) VALUES( :fullname, :email, :place_area, :venue_name, :venue_book_status, :venue_ratings, :venue_image, :venue_latitude, :venue_longitude, :venue_search)");
   
//     // $stmt->bindParam(':aid', $aid, PDO::PARAM_STR);
//     $stmt->bindParam(':fullname', $fullname, PDO::PARAM_STR);
//     $stmt->bindParam(':place_area', $place_area, PDO::PARAM_STR);
//     $stmt->bindParam(':venue_name', $venue_name, PDO::PARAM_STR);
//     $stmt->bindParam(':venue_book_status', $venue_book_status, PDO::PARAM_STR);
//     $stmt->bindParam(':venue_ratings', $venue_ratings, PDO::PARAM_STR);
//     // $stmt->bindParam(':venue_images', $venue_images, PDO::PARAM_STR);
//     $stmt->bindParam(':venue_latitude', $venue_latitude, PDO::PARAM_STR);
//     $stmt->bindParam(':venue_longitude', $venue_longitude, PDO::PARAM_STR);
//     $stmt->bindParam(':venue_search', $venue_search, PDO::PARAM_STR);
       
//     // $aid = $_POST['aid'];
//     $fullname = $_POST['fullname'];
//     $place_area = $_POST['place_area'];
//     $venue_name = $_POST['venue_name'];
//     $venue_book_status = $_POST['venue_book_status'];
//     $venue_ratings = $_POST['venue_ratings'];
//     $venue_latitude = $_POST['venue_latitude'];
//     $venue_longitude = $_POST['venue_longitude'];
//     $venue_search = $_POST['venue_search'];

       
//     $stmt->execute();
//     }
 
//   catch(PDOException $e)
//   {
//       echo "Error: " . $e->getMessage();
//   }
// }
 
//Update
if (isset($_POST['update'])) {
   
  try {
    $stmt = $conn->prepare("UPDATE venue_list SET fullname = :fullname, email = :email, place_area = :place_area, venue_name = :venue_name, venue_book_status = :venue_book_status, venue_ratings = :venue_ratings, venue_latitude = :venue_latitude, venue_longitude = :venue_longitude, venue_search = :venue_search WHERE venue_id = :oldvid");
   
    // $stmt->bindParam(':aid', $aid, PDO::PARAM_STR);
    $stmt->bindParam(':fullname', $fullname, PDO::PARAM_STR);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':place_area', $place_area, PDO::PARAM_STR);
    $stmt->bindParam(':venue_name', $venue_name, PDO::PARAM_STR);
    $stmt->bindParam(':venue_book_status', $venue_book_status, PDO::PARAM_STR);
    $stmt->bindParam(':venue_ratings', $venue_ratings, PDO::PARAM_STR);
    $stmt->bindParam(':venue_latitude', $venue_latitude, PDO::PARAM_STR);
    $stmt->bindParam(':venue_longitude', $venue_longitude, PDO::PARAM_STR);
    $stmt->bindParam(':venue_search', $venue_search, PDO::PARAM_STR);
    $stmt->bindParam(':oldvid', $oldvid, PDO::PARAM_STR);
       
    // $aid = $_POST['aid'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $place_area = $_POST['place_area'];
    $venue_name = $_POST['venue_name'];
    $venue_book_status = $_POST['venue_book_status'];
    $venue_ratings = $_POST['venue_ratings'];
    $venue_latitude = $_POST['venue_latitude'];
    $venue_longitude = $_POST['venue_longitude'];
    $venue_search = $_POST['venue_search'];
    $oldvid = $_POST['oldvid'];
       
    $stmt->execute();
 
    header("Location: venuetable.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Delete
if (isset($_GET['delete'])) {
 
  try {
 
    $stmt = $conn->prepare("DELETE FROM venue_list WHERE venue_id = :vid");
   
    $stmt->bindParam(':vid', $vid, PDO::PARAM_STR);
       
    $vid = $_GET['delete'];
     
    $stmt->execute();
 
    header("Location: venuetable.php");
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
//Edit
if (isset($_GET['edit'])) {
   
  try {
 
    $stmt = $conn->prepare("SELECT * FROM venue_list WHERE venue_id = :vid");
   
    $stmt->bindParam(':vid', $vid, PDO::PARAM_STR);
       
    $vid = $_GET['edit'];
     
    $stmt->execute();
 
    $editrow = $stmt->fetch(PDO::FETCH_ASSOC);
    }
 
  catch(PDOException $e)
  {
      echo "Error: " . $e->getMessage();
  }
}
 
  $conn = null;
 
?>