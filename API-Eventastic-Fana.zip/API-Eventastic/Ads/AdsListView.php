<?php
require "../db.php";

if (isset($_POST['process'])) {
    $process=$_POST['process'];

    if ($process=='list') {
       
            $stmt = $conn->prepare("SELECT * FROM ads_user WHERE username=:username AND event_id=:event_id");

            $stmt->bindParam(':username', $username, PDO::PARAM_STR);
            $stmt->bindParam(':event_id', $event_id, PDO::PARAM_STR);
            
            $username = $_POST['username'];
            $event_id = $_POST['event_id'];

            $stmt->execute();
            $user=$stmt->fetchAll(PDO::FETCH_ASSOC);
            if(isset($user)){

               echo json_encode($user) ;
            }else echo "500";
        
    } 
    else if ($process=='insert') {
        try{

        $stmt = $conn->prepare("INSERT INTO ads_user(username,name,category,notes,status,event_id) VALUES(:username,:name,:category,:notes,:status,:event_id)");

            $stmt->bindParam(':username', $username, PDO::PARAM_STR);
            $stmt->bindParam(':name', $name, PDO::PARAM_STR);
            $stmt->bindParam(':category', $category, PDO::PARAM_STR);
            $stmt->bindParam(':notes', $notes, PDO::PARAM_STR);
            $stmt->bindParam(':status', $status, PDO::PARAM_STR);
            $stmt->bindParam(':event_id', $event_id, PDO::PARAM_STR);
            
            $username = $_POST['username'];
            $name = $_POST['name'];
            $category = $_POST['category'];
            $notes = $_POST['notes'];
            $status = $_POST['status'];
            $event_id = $_POST['event_id'];
            
            $stmt->execute();
            echo "200";
            
            
        }catch(PDOException $e){

            echo $e->getMessage();

        }
    }


}

?>
